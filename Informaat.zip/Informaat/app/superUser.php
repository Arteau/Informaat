<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class superUser extends Model
{
    //
}
