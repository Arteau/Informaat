<?php if(count($errors)): ?>
     
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script>
        $(function() {
        Materialize.toast('<?php echo e($error); ?>', 4000);
        });
        </script>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
<?php endif; ?>