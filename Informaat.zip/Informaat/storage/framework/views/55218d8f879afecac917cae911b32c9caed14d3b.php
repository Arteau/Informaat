<?php $__env->startSection('content'); ?>
<br>
<div class="container" style="margin-top:50px">
<?php if(!Auth::user()->isAdmin): ?>

<table class="striped">
        <thead>
          <tr>
              <th>Alle gebruikers voor <?php echo e($jeugdhuis->name); ?></th>
          </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($user->name); ?></td>
            
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

    
<?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>