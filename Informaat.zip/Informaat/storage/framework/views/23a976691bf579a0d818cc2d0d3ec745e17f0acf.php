<?php $__env->startSection('content'); ?>
    <!-- /.container -->
<div class="container" style="margin-top:50px; margin-bottom:50px;">

  
<blockquote>
  Top posts deze week
</blockquote>

  <div class="row">
 
  <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="/posts/<?php echo e($top->id); ?>">
    <div class="col s6 m3" class="top">
      <div class="card hoverable">
        <div class="card-image valign-wrapper" style="padding:20px; padding-bottom:0;background-color:#f79727">
          <?php if($top->topic == "techniek"): ?>
            <img src="<?php echo e(asset('img/icon_techniek_white.svg')); ?>" alt="" style="max-height:80px; left: 50%;transform: translateX(-50%);"> 
          <?php elseif($top->topic == "sociaal"): ?>
            <img src="<?php echo e(asset('img/icon_social_white.svg')); ?>" alt="" style="max-height:80px; left: 50%;transform: translateX(-50%);"> 
          <?php else: ?>
            <img src="<?php echo e(asset('img/icon_sound_white.svg')); ?>" alt="" style="max-height:80px; left: 50%;transform: translateX(-50%);"> 
          <?php endif; ?>
          <span class="card-title"></span>
        </div>
        <div class="card-content" style="background-color:#f79727">
        <span style="position: absolute;top: 2px;color: black;left: 3px;">
          <i class="material-icons" style="color:rgba(246, 248, 251, 0.83); font-size:17px">thumb_up</i>
          <span style="top: -3px;left: 21px;position: absolute; color:rgba(246, 248, 251, 0.83)"><?php echo e($top->votes); ?></span>
        </span> 
        <b><p class="truncate center-align white-text"><?php echo e($top->title); ?></p></b>
         
        </div>
        <div class="card-action center-align black-text">
          Lees meer
        </div>
      </div>
    </div> 
  </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

 <hr>
  <div class="row">
    <div class="col m6 s12">
      <form role="search" class="app-search" action="/posts/search" method="POST">
        <?php echo e(csrf_field()); ?>


          <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <label for="keyword">Zoeken</label>
          <input type="text" name="keyword" id="keyword"  class="field-input" style="width:100%"> <a href=""></a>
      </form>
    </div>

    <div class="col m6 s12">
      <form role="sort" class="app-sort" id="sort-form" action="/posts/sort" method="POST">
          <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <label for="keyword">Sorteer op</label>
              <select class="field-input"  name="sort" id="sort">
                <option value="created_at desc" <?php if(session('option') == "created_at desc"): ?> selected <?php endif; ?>>Jongste eerst</option>
                <option value="created_at asc" <?php if(session('option') == "created_at asc"): ?> selected <?php endif; ?>>Oudste eerst</option>
                <option value="votes desc" <?php if(session('option') == "votes desc"): ?> selected <?php endif; ?>>Most votes</option>
                <option value="title asc" <?php if(session('option') == "title asc"): ?> selected <?php endif; ?>>Titel: A - Z</option>
                <option value="title desc" <?php if(session('option') == "title desc"): ?> selected <?php endif; ?>>Titel: Z - A</option>
              </select>
            </div>
            <noscript><button type="submit">sort</button></noscript>
        </form>
      </div>
    </div>
    <blockquote>
      Alle posts
    </blockquote>
    <div class="col s12 m12">
  
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/posts/<?php echo e($post->id); ?>">
      <div class="row z-depth-2 hoverable" style="color:#636b6f; min-height:118px;height:182px">
        <div class="col s12 m1 hide-on-small-only	" style="position:relative">
          <div style="position:absolute" class="votes"><?php echo e($post->votes); ?></div>
              <div style="position:absolute" class="votes_caret">
                  <?php if(!$user->hasVoted($post)): ?>
                  <object><a href="/posts/<?php echo e($post->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a></object>
                  <object><a href="/posts/<?php echo e($post->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a></object>
                  <?php else: ?>
                      <?php if($user->hasUpVoted($post)): ?>
                          <object><a href="/posts/<?php echo e($post->id); ?>/cancelvote" class="upvote cancelvote"><i class="fa fa-caret-up" aria-hidden="true" ></i></a></object>
                          <object><a href="/posts/<?php echo e($post->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a></object>
                      <?php endif; ?>
                      <?php if($user->hasDownVoted($post)): ?>
                          <object><a href="/posts/<?php echo e($post->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a></object>
                          <object><a href="/posts/<?php echo e($post->id); ?>/cancelvote" class="downvote  cancelvote"><i class="fa fa-caret-down" aria-hidden="true" ></i></a></object>
                      <?php endif; ?>
                  <?php endif; ?>
              </div>
        </div>
        <div class="col s12 m2 hide-on-small-only	" style="position:relative; height:182px">
        <?php if($post->topic == "techniek"): ?>
          <img src="<?php echo e(asset('img/icon_techniek.svg')); ?>" alt="" style="max-height:100px;position: absolute;left: 50%;transform: translate(-50%, 50%);">  
        <?php elseif($post->topic == "sociaal"): ?>
        <img src="<?php echo e(asset('img/icon_social.svg')); ?>" alt="" style="max-height:100px;position: absolute;left: 50%;transform: translate(-50%, 50%);">  

        <?php else: ?>
        <img src="<?php echo e(asset('img/icon_sound.svg')); ?>" alt="" style="max-height:100px;position: absolute;left: 50%;transform: translate(-50%, 50%);">  

        <?php endif; ?>
        </div>
        <div class="col s10 m8">
          <div class="">
                  
                  <h5 class=""><?php echo e($post->title); ?></h5>
                  <i class="truncate"><?php echo e($post->body); ?></i>
                  
                  
                 
                  <?php if(!empty($post->tag1 | $post->tag2 | $post->tag3)): ?>
                  <small><b>Tags: </b><?php echo e($post->tag1); ?> | <?php echo e($post->tag2); ?> | <?php echo e($post->tag3); ?></small>
                  <?php else: ?>
                  <small><br></small>
                  <?php endif; ?>
                  <p><small><b>Gepost door:</b> <?php echo e($post->user->name); ?> van <?php echo e($post->user->jeugdhuis->name); ?>  </small></p>
                  <p><small><b><?php echo e(count($post->comments)); ?> comments </b> </small></p>
          </div>
          <div class="col s12 m12">
          
          </div>
        </div>
        <div class="col s2 m1" >
          <!-- -->
          <div style="position:relative">
            
          
          <?php if( count($post->favorites->where('user_id', auth()->id())) ): ?>

                    <form action="/posts/<?php echo e($post->id); ?>/unfavorite" method="POST" class="favorite">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('PATCH')); ?>

                      
                      <button type="submit" class="star">
                        <i class="fa fa-star" aria-hidden="true"></i>
                      </button>
                    </form>
                  <?php else: ?>
                
                    <form action="/posts/<?php echo e($post->id); ?>/favorite" method="POST" class="favorite">
                      <?php echo e(csrf_field()); ?>

                      
                      <button type="submit" class="star"><i class="fa fa-star-o" aria-hidden="true"></i></button>
                    </form>

          <?php endif; ?>
          </div>
        </div>
      </div>
      </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($posts->links()); ?>

    <a href="/posts/create"><button class="btn btn-default">Create post</button></a>
</div>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>