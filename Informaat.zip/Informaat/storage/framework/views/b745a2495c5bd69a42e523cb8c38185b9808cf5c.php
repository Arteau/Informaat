<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:50px">

    <form role="search" class="app-search" action="/posts/search" method="POST">
        <?php echo e(csrf_field()); ?>


            <input type="text" name="keyword" id="keyword" placeholder="Zoeken" class="form-control" style="width:100%">
    </form>
    
    <?php if(!empty($searchPost)): ?>

        <?php if(isset($searchPost)): ?>
        <?php if(empty($searchPost[0])): ?>
            <br>
            <h3 class="text-center">Whooops, geen resultaten gevonden!</h3>
        <?php endif; ?>
        <?php endif; ?>

        <?php $__currentLoopData = $searchPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="card horizontal z-depth-2 hoverable">
        <div class="card-image" style="width:150px">
        <div style="position:absolute">
             <img src="<?php echo e(asset('img/icon_sound.svg')); ?>" alt="" style="width:100%">
          </div>
          
        </div>
        <div class="card-stacked">
          <div class="card-content">
                <?php echo e($post->votes); ?>

                  <?php if(!$user->hasVoted($post)): ?>
                  <a href="/posts/<?php echo e($post->id); ?>/upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a>
                  <a href="/posts/<?php echo e($post->id); ?>/downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a>
                  <?php else: ?>
                      <?php if($user->hasUpVoted($post)): ?>
                          <a href="/posts/<?php echo e($post->id); ?>/cancelvote"><i class="fa fa-caret-up" aria-hidden="true" style="color:black"></i></a>
                          <a href="/posts/<?php echo e($post->id); ?>/downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a>
                      <?php endif; ?>
                      <?php if($user->hasDownVoted($post)): ?>
                          <a href="/posts/<?php echo e($post->id); ?>/upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a>
                          <a href="/posts/<?php echo e($post->id); ?>/cancelvote"><i class="fa fa-caret-down" aria-hidden="true" style="color:black"></i></a>
                      <?php endif; ?>
                  <?php endif; ?>

                  <h2 class="card-title"><?php echo e($post->title); ?></h2>
                  <i><?php echo e($post->body); ?></i>
                  <hr>
                  
                  <p>Onderwerp: <?php echo e($post->topic); ?></p> 
                  <?php if(!empty($post->tag1 | $post->tag2 | $post->tag3)): ?>
                  <small><?php echo e($post->tag1); ?> // <?php echo e($post->tag2); ?> // <?php echo e($post->tag3); ?></small>
                  <?php endif; ?>
                  <p><small><b>Gepost door:</b> <?php echo e($post->user->name); ?>  van <?php echo e($post->user->jeugdhuis->name); ?></small></p>
                    <p><small><b><?php echo e(count($post->comments)); ?> comments </b> </small></p>
          </div>
          <div class="card-action">
            <a href="/posts/<?php echo e($post->id); ?>">Lees meer</a>
          </div>
        </div>
      </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>