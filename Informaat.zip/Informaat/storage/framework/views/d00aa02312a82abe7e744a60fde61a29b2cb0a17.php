<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:50px">
<h5>Jeugdhuis toevoegen</h5>
<form action="/jeugdhuizen" method="POST">
            <?php echo e(csrf_field()); ?>

            
        <div class="input-field">
            <label for="name">Naam</label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" class="form-control">
        </div>

        <div class="input-field">
            <label for="village">Stad</label>
            <input type="text" name="village" id="village" value="<?php echo e(old('village')); ?>" class="form-control">
        </div>

        <div class="input-field">
            <label for="zipcode">Postcode</label>
            <input type="number" name="zipcode" id="zipcode" value="<?php echo e(old('zipcode')); ?>" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Publish jeugdhuis</button>
        <a href="/jeugdhuizen"><div class="btn btn-danger">Back</div></a>

    </form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>