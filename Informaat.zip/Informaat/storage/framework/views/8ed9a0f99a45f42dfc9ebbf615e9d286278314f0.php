<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top:50px">


<div class="card">
    <div class="card-content">
      <h5 class="text-center"><?php echo e($user->name); ?> / <?php if(!empty($user->jeugdhuis->name)): ?><?php echo e($user->jeugdhuis->name); ?><?php endif; ?> </h5>
    </div>
    <div class="card-tabs">
      <ul class="tabs tabs-fixed-width">
        <li class="tab"><a class="active" href="#favorieten">Favorieten</a></li>
        <li class="tab"><a href="#mijn_posts">Mijn posts</a></li>
        <li class="tab"><a href="#mijn_comments">Mijn comments</a></li>
      </ul>
    </div>
    <div class="card-content grey lighten-4">
        <div id="favorieten">


        <?php $__currentLoopData = $favorite_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <a href="/posts/<?php echo e($favorite->post->id); ?>">
        <div class="row z-depth-2 hoverable" style="color:#636b6f; min-height:118px;">
          <div class="col s12 m1 hide-on-small-only	" style="position:relative">
            <div style="position:absolute" class="votes"><?php echo e($favorite->post->votes); ?></div>
                <div style="position:absolute" class="votes_caret">
                    <?php if(!$user->hasVoted($favorite->post)): ?>
                    <object><a href="/posts/<?php echo e($favorite->post->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a></object>
                    <object><a href="/posts/<?php echo e($favorite->post->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a></object>
                    <?php else: ?>
                        <?php if($user->hasUpVoted($favorite->post)): ?>
                            <object><a href="/posts/<?php echo e($favorite->post->id); ?>/cancelvote" class="upvote cancelvote"><i class="fa fa-caret-up" aria-hidden="true" ></i></a></object>
                            <object><a href="/posts/<?php echo e($favorite->post->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a></object>
                        <?php endif; ?>
                        <?php if($user->hasDownVoted($favorite->post)): ?>
                            <object><a href="/posts/<?php echo e($favorite->post->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a></object>
                            <object><a href="/posts/<?php echo e($favorite->post->id); ?>/cancelvote" class="downvote  cancelvote"><i class="fa fa-caret-down" aria-hidden="true" ></i></a></object>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
          </div>
          <div class="col s12 m2 hide-on-small-only	" style="position:relative">
          <?php if($favorite->post->topic == "techniek"): ?>
            <img src="<?php echo e(asset('img/icon_techniek.svg')); ?>" alt="" style="max-height:100px;position: absolute;left: 50%;transform: translateX(-50%);top: 10px;">  
          <?php elseif($favorite->post->topic == "sociaal"): ?>
          <img src="<?php echo e(asset('img/icon_social.svg')); ?>" alt="" style="max-height:100px;position: absolute;left: 50%;transform: translateX(-50%);top: 10px;">  
  
          <?php else: ?>
          <img src="<?php echo e(asset('img/icon_sound.svg')); ?>" alt="" style="max-height:100px;position: absolute;left: 50%;transform: translateX(-50%);top: 10px;">  
  
          <?php endif; ?>
          </div>
          <div class="col s10 m8">
            <div class="">
                    
                    <h5 class=""><?php echo e($favorite->post->title); ?></h5>
                    <i class="truncate"><?php echo e($favorite->post->body); ?></i>
                    
                    
                   
                    <?php if(!empty($favorite->post->tag1 | $favorite->post->tag2 | $favorite->post->tag3)): ?>
                    <small><b>Tags: </b><?php echo e($favorite->post->tag1); ?> | <?php echo e($favorite->post->tag2); ?> | <?php echo e($favorite->post->tag3); ?></small>
                    <?php else: ?>
                    <small><br></small>
                    <?php endif; ?>
                    
                    <p><small><b>Gepost door:</b> <?php echo e($favorite->post->user->name); ?> van  <?php echo e($favorite->post->user->jeugdhuis->name); ?></small></p>
                    <p><small><b><?php echo e(count($favorite->post->comments)); ?> comments </b> </small></p>
            </div>
            <div class="col s12 m12">
            
            </div>
          </div>
          <div class="col s2 m1" >
            <!-- -->
            <div style="position:relative">
              
            
            <?php if( count($favorite->post->favorites->where('user_id', auth()->id())) ): ?>
  
                      <form action="/posts/<?php echo e($favorite->post->id); ?>/unfavorite" method="POST" class="favorite">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>

                        
                        <button type="submit" class="star">
                          <i class="fa fa-star" aria-hidden="true"></i>
                        </button>
                      </form>
                    <?php else: ?>
                  
                      <form action="/posts/<?php echo e($favorite->post->id); ?>/favorite" method="POST" class="favorite">
                        <?php echo e(csrf_field()); ?>

                        
                        <button type="submit" class="star"><i class="fa fa-star-o" aria-hidden="true"></i></button>
                      </form>
  
            <?php endif; ?>
            </div>
          </div>
        </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





            
        </div>
        <div id="mijn_posts">
            
        
        <?php $__currentLoopData = $user_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/posts/<?php echo e($post->id); ?>">
        <div class="row z-depth-2 hoverable" style="color:#636b6f; min-height:118px;">
          <div class="col s12 m1 hide-on-small-only	" style="position:relative">
            <div style="position:absolute" class="votes"><?php echo e($post->votes); ?></div>
                <div style="position:absolute" class="votes_caret">
                    <?php if(!$user->hasVoted($post)): ?>
                    <object><a href="/posts/<?php echo e($post->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a></object>
                    <object><a href="/posts/<?php echo e($post->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a></object>
                    <?php else: ?>
                        <?php if($user->hasUpVoted($post)): ?>
                            <object><a href="/posts/<?php echo e($post->id); ?>/cancelvote" class="upvote cancelvote"><i class="fa fa-caret-up" aria-hidden="true" ></i></a></object>
                            <object><a href="/posts/<?php echo e($post->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a></object>
                        <?php endif; ?>
                        <?php if($user->hasDownVoted($post)): ?>
                            <object><a href="/posts/<?php echo e($post->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a></object>
                            <object><a href="/posts/<?php echo e($post->id); ?>/cancelvote" class="downvote  cancelvote"><i class="fa fa-caret-down" aria-hidden="true" ></i></a></object>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
          </div>
          <div class="col s12 m2 hide-on-small-only	" style="position:relative">
          <?php if($post->topic == "techniek"): ?>
            <img src="<?php echo e(asset('img/icon_techniek.svg')); ?>" alt="" style="max-height:100px;position: absolute;left: 50%;transform: translateX(-50%);top: 10px;">  
          <?php elseif($post->topic == "sociaal"): ?>
          <img src="<?php echo e(asset('img/icon_social.svg')); ?>" alt="" style="max-height:100px;position: absolute;left: 50%;transform: translateX(-50%);top: 10px;">  
  
          <?php else: ?>
          <img src="<?php echo e(asset('img/icon_sound.svg')); ?>" alt="" style="max-height:100px;position: absolute;left: 50%;transform: translateX(-50%);top: 10px;">  
  
          <?php endif; ?>
          </div>
          <div class="col s10 m8">
            <div class="">
                    
                    <h5 class=""><?php echo e($post->title); ?></h5>
                    <i class="truncate"><?php echo e($post->body); ?></i>
                    
                    
                   
                    <?php if(!empty($post->tag1 | $post->tag2 | $post->tag3)): ?>
                    <small><b>Tags: </b><?php echo e($post->tag1); ?> | <?php echo e($post->tag2); ?> | <?php echo e($post->tag3); ?></small>
                    <?php else: ?>
                    <small><br></small>
                    <?php endif; ?>
                    <p><small><b>Gepost door:</b> <?php echo e($post->user->name); ?>  van <?php echo e($post->user->jeugdhuis->name); ?></small></p>
                    
                    <p><small><b><?php echo e(count($post->comments)); ?> comments </b> </small></p>
            </div>
            <div class="col s12 m12">
            
            </div>
          </div>
          <div class="col s2 m1" >
            <!-- -->
            <div style="position:relative">
              
            
            <?php if( count($post->favorites->where('user_id', auth()->id())) ): ?>
  
                      <form action="/posts/<?php echo e($post->id); ?>/unfavorite" method="POST" class="favorite">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>

                        
                        <button type="submit" class="star">
                          <i class="fa fa-star" aria-hidden="true"></i>
                        </button>
                      </form>
                    <?php else: ?>
                  
                      <form action="/posts/<?php echo e($post->id); ?>/favorite" method="POST" class="favorite">
                        <?php echo e(csrf_field()); ?>

                        
                        <button type="submit" class="star"><i class="fa fa-star-o" aria-hidden="true"></i></button>
                      </form>
  
            <?php endif; ?>
            </div>
          </div>
        </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    



        </div>
        <div id="mijn_comments">
            



      <?php if(!empty($post)): ?>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card horizontal z-depth-2">
      <div class="card-image">
       <!-- image here -->
      </div>
      <div class="card-stacked">
        <div class="card-content">
        <?php echo e($comment->votes); ?>

            <?php if(!$user->hasVoted($comment)): ?>
            <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a>
            <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a>
            <?php else: ?>
                <?php if($user->hasUpVoted($comment)): ?>
                    <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/cancelvote"><i class="fa fa-caret-up" aria-hidden="true" style="color:black"></i></a>
                    <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a>
                <?php endif; ?>
                <?php if($user->hasDownVoted($comment)): ?>
                    <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a>
                    <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/cancelvote"><i class="fa fa-caret-down" aria-hidden="true" style="color:black"></i></a>
                <?php endif; ?>
            <?php endif; ?>

                <h2 class="card-title"><?php echo e($comment->title); ?></h2>
                <i><?php echo e($comment->body); ?></i>
                <br>
                <small> Gepost: <?php echo e($comment->created_at->diffForHumans()); ?> door
                <?php echo e($comment->user->name); ?> van <?php echo e($comment->user->jeugdhuis->name); ?></small>
        </div>
        <div class="card-action">
          <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/edit">Edit comment </a>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    










        </div>
    </div>
  </div>

   

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>