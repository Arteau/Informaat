<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:50px;">

    <div class="col row z-depth-2" style="min-height:230px">
      <div class="col m2" >
          <div class="valign-wrapper" style="position:relative">
          <div style="position: absolute;top: 3rem;left: 2%;">
             <img src="<?php echo e(asset('img/icon_sound.svg')); ?>" alt="" style="width:100%">
          </div>
        </div>
          
      </div>
      <div class="col m10">
        <div class="row">
            <div style="position:relative">

            <?php if( count($post->favorites->where('user_id', auth()->id())) ): ?>
                
                    <form action="/posts/<?php echo e($post->id); ?>/unfavorite" method="POST" style="position:absolute; right:0">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('PATCH')); ?>

                      
                      <button type="submit" class="star">
                        <i class="fa fa-star" aria-hidden="true"></i>
                      </button>
                    </form>
                  
                  <?php else: ?>
                
                    <form action="/posts/<?php echo e($post->id); ?>/favorite" method="POST" style="position:absolute; right:0">
                      <?php echo e(csrf_field()); ?>

                      
                      <button type="submit" class="star"><i class="fa fa-star-o" aria-hidden="true"></i></button>
                    </form>

                  <?php endif; ?>
            
            </div>
            
            <div class="col m12">
                <h4 class="card-title"><b><?php echo e($post->title); ?></b></h4>
                <i><?php echo e($post->body); ?></i>
                <hr>
            </div>
                <div class="col m10">
                    <br>
                    <?php if(!empty($post->tag1 | $post->tag2 | $post->tag3)): ?>
                    <small><b>Tags: </b><?php echo e($post->tag1); ?> | <?php echo e($post->tag2); ?> | <?php echo e($post->tag3); ?></small>
                    <?php endif; ?>
                    <p><small><b>Gepost door:</b> <?php echo e($post->user->name); ?>  van <?php echo e($post->user->jeugdhuis->name); ?></small></p>
                    <p><small><b><?php echo e(count($post->comments)); ?> comments </b> </small></p>
                </div>

                <div class="col m2">
              <?php echo e($post->votes); ?>

                <?php if(!$user->hasVoted($post)): ?>
                <a href="/posts/<?php echo e($post->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a>
                <a href="/posts/<?php echo e($post->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a>
                <?php else: ?>
                    <?php if($user->hasUpVoted($post)): ?>
                        <a href="/posts/<?php echo e($post->id); ?>/cancelvote" class="upvote cancelvote"><i class="fa fa-caret-up" aria-hidden="true" style="color:black"></i></a>
                        <a href="/posts/<?php echo e($post->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a>
                    <?php endif; ?>
                    <?php if($user->hasDownVoted($post)): ?>
                        <a href="/posts/<?php echo e($post->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a>
                        <a href="/posts/<?php echo e($post->id); ?>/cancelvote" class="downvote cancelvote"><i class="fa fa-caret-down" aria-hidden="true" style="color:black"></i></a>
                    <?php endif; ?>
                <?php endif; ?>


                

                  </div>
        </div>
        <?php if($post->user_id == Auth::user()->id): ?>
        <div class="card-action">
          <a href="/posts/<?php echo e($post->id); ?>/edit">Edit post</a>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <hr>
    <?php if(count($comments) != 0): ?>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card horizontal z-depth-2">
      <div class="card-image">
       <!-- image here -->
      </div>
      <div class="card-stacked">
        <div class="card-content">
        <?php echo e($comment->votes); ?>

            <?php if(!$user->hasVoted($comment)): ?>
            <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a>
            <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a>
            <?php else: ?>
                <?php if($user->hasUpVoted($comment)): ?>
                    <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/cancelvote" class="upvote cancelvote"><i class="fa fa-caret-up" aria-hidden="true" style="color:black"></i></a>
                    <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/downvote" class="downvote"><i class="fa fa-caret-down" aria-hidden="true"></i></a>
                <?php endif; ?>
                <?php if($user->hasDownVoted($comment)): ?>
                    <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/upvote" class="upvote"><i class="fa fa-caret-up" aria-hidden="true"></i></a>
                    <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/cancelvote" class="downvote cancelvote"><i class="fa fa-caret-down" aria-hidden="true" style="color:black"></i></a>
                <?php endif; ?>
            <?php endif; ?>
            

                <h2 class="card-title"><?php echo e($comment->title); ?></h2>
                <i><?php echo e($comment->body); ?></i>
                <hr>
                <small> Gepost: <?php echo e($comment->created_at->diffForHumans()); ?> door
                <?php echo e($comment->user->name); ?> van <?php echo e($comment->user->jeugdhuis->name); ?></small>
        </div>
        <?php if($comment->user_id == Auth::user()->id): ?>
        <div class="card-action">
          <a href="/posts/<?php echo e($post->id); ?>/comment/<?php echo e($comment->id); ?>/edit">Reactie aanpassen</a>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <?php else: ?>
    <small>Nog geen reactie's, wees de eerste om te reageren!</small>
    <br>
    <?php endif; ?>
    <?php echo e($comments->links()); ?>


    
   


    

    <ul class="collapsible hoverable " data-collapsible="accordion">
        <li>
            <div class="collapsible-header btn" style="height:50px; border-radius:5px;">
                <i class="material-icons"></i>Reactie geven
            </div>
            <div class="collapsible-body">
                <form action="/posts/<?php echo e($post->id); ?>/comment/store" method="POST">
                        <?php echo e(csrf_field()); ?>

                        
                    <div class="input-field">
                        <label for="title">Titel</label>
                        <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>" class="form-control">
                    </div>

                    <div class="input-field">
                        <label for="body">Commentaar</label>
                        <input type="text" name="body" id="body" value="<?php echo e(old('body')); ?>" class="form-control">
                    </div>

                    <button type="submit" class="btn btn-primary">Publish comment</button>
                    <a href="/posts"><div class="btn btn-danger">Back</div></a>
            
                </form>
            </div>
        </li>
    </ul>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>