<?php if($flash = session('message')): ?>

    <script>
    $(function() {
      Materialize.toast('<?php echo e($flash); ?>', 4000);
    });
    </script>

    <?php endif; ?>