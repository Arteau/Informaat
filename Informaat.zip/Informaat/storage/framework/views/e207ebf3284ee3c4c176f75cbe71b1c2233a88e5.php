<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top:50px">
  <div class="row">
  <blockquote>Overzicht jeugdhuizen</blockquote>
  
    <ul class="collapsible popout" data-collapsible="accordion" style="margin-top:50px">
    <?php $__currentLoopData = $jeugdhuizen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jeugdhuis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <div class="collapsible-header"><i class="material-icons">home</i><?php echo e($jeugdhuis->name); ?></div>
          <div class="collapsible-body"><span><?php echo e($jeugdhuis->zipcode); ?> <?php echo e($jeugdhuis->village); ?>  </span>
          <hr>
          <small><b>Leden van jeugdhuis:</b></small>
          <ul>
            <?php $__currentLoopData = $jeugdhuis->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($user->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </ul>
            <a href="/jeugdhuizen/<?php echo e($jeugdhuis->id); ?>/edit"><i class="material-icons">create</i></a>
          </div>
         
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <a href="/jeugdhuizen/create"><span class="btn-block btn btn-primary"> Jeugdhuis Toevoegen</span></a>
 

  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>