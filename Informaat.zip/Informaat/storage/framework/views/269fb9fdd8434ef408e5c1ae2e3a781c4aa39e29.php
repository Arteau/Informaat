<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h4 class="page-title">Maak post!</h4> 
        </div>
    </div>

    <form method="POST" action="/posts" id="post_form">

     <?php echo e(csrf_field()); ?>

   
    <div class="input-field">
        <label for="title">Titel*</label>
        <input name="title" id="title" type="text" value="<?php echo e(old('title')); ?>" class="form-control">
    </div>

    <div class="input-field">
        <label for="body">Vraag of opmerking*</label>
        <input type="text" name="body" id="body" value="<?php echo e(old('body')); ?>" class="form-control">
    </div>


    <div class="input-field">
        <select id="topic" name="topic">
            <option disabled selected>Onderwerp*</option>
            <option value="sociaal">Sociaal</option>
            <option value="techniek">Techniek</option>
            <option value="muziek">Muziek</option>
            
        </select>
    </div>

    <div class="input-field">
        <label for="tag1">Tag 1</label>
        <input type="text" name="tag1" id="tag1" value="<?php echo e(old('tag1')); ?>" class="form-control">
    </div>
    <div class="input-field">
        <label for="tag2">Tag 2</label>
        <input type="text" name="tag2" id="tag2" value="<?php echo e(old('tag2')); ?>" class="form-control">
    </div>
    <div class="input-field">
        <label for="tag3">Tag 3</label>
        <input type="text" name="tag3" id="tag3" value="<?php echo e(old('tag3')); ?>" class="form-control">
    </div>

    <button type="submit" class="btn btn-primary" id="post_button_submit">Publish post</button>
    <a href="/posts"><div class="btn btn-danger">Back</div></a>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>